const app = Vue.createApp({
  data() {
    return {};
  },
  methods: {},
});

app.mount("#events");
