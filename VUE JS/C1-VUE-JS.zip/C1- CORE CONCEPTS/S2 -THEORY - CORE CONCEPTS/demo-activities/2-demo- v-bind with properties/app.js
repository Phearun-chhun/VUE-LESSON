const app = Vue.createApp({
  data() {
    return {
      objective: "learn Vue 3",
      vueLink: "https://v3.vuejs.org/",
    };
  },
});

app.mount("#app");
