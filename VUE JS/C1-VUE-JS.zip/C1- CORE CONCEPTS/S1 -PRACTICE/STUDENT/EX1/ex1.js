new Vue({
  el: "#exercise",
  data: {
    result: 0,
  },
  methods: {
    computeOperation() {
    
    },
  },
});
