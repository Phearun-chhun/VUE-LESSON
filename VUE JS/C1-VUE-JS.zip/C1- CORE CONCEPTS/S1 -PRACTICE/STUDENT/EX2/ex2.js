new Vue({
  el: "#exercise",
  data: {
	htmlAverage:0,
    scores: [
      { name: "a", topic: "HTML", result: 30 },
      { name: "b", topic: "JAVA", result: 40 },
      { name: "c", topic: "JS", result: 51 },
    ],
  },
  methods: {
    updateHtmlAverage() {
       
    },
    addScore() {
      
    },
  },
  mounted() {
    
  },
});
