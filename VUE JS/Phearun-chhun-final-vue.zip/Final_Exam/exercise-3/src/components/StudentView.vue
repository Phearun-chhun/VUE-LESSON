<template>
  <div class="student_view" >
    <student-card v-for="student in students" :key="student" :studentId="student.id" >
    </student-card>
  </div>
</template>

<script>
import StudentCard from './StudentCard.vue';
export default {
    inject: ['students'],
    components: {
        'student-card':StudentCard
    }    
}
</script>

<style>

</style>