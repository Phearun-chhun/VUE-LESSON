<template>
    <div class="card">
        <h1>Student card id: {{studentDetail.id}}</h1>
    </div>
</template>

<script>
export default {
    props: ['studentId'],
    inject: ['students'],
    computed: {
        studentDetail() {
            for (let student of this.students) {
                if (this.$route.params.studentId == student.id) {
                    return student;
                }
            }
            return "no name and position"
            // return
        }
    }
}
</script>

<style>

</style>