<template>
  <nav>
    <router-link to="/">Student1</router-link> |
    <router-link to="/student/2">Student2</router-link> |
    <router-link to="/student/3">Student3</router-link>
  </nav>
  <router-view/>
</template>

<style>
#app {
display: flex;

}

nav {
  padding: 30px;
  background: rgb(4, 4, 250);
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
}

nav a {
  font-weight: bold;
  color: #fff;
}

nav a.router-link-exact-active {
  color: #42b983;
  border: 2px solid orange;
  padding: 5px;
}
</style>
