<template>
  <div class="about">
    <student-view></student-view>
  </div>
</template>
<script>
import StudentView from "@/components/StudentView.vue"
export default {
  components: {
    'student-view':StudentView
  },
  data(){
    return {
      students: [
          {id:2,text:"This is studen ID 2"},
          {id:3,text:"This is studen ID 3"},
        ]
      }
  },
  provide() {
    return {
      students:this.students
    }
  }
}
</script>
<style scoped> 
  .about { 
    margin-top: 5%;
  }
</style>