<template>
  <div class="home">
    <h1>This is student</h1>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'HomeView',
  components: {
  }
}
</script>
<style scoped>
  .home {
    margin-top: 5%;
    }
</style>