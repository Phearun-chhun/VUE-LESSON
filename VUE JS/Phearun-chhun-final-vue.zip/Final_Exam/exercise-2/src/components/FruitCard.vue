<template>
    <div class="card" v-for="(fruit, id) in fruits" :key="fruit.id" :style="{ background:  fruit.color  }">
        <h1>{{fruit.fruit}}</h1>
        <button @click="removeData($event)" :id="id">DELETE</button>
    </div>
</template>

<script>
export default {
    inject:['fruits']
}
</script>

<style scoped>

.card {
    box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
    border-radius: 10px;
    padding: 15px;
    text-align: left;
    margin-top: 15px;
}

.card h2 {
    margin: 0;
    margin-bottom: 15px;
}

</style>