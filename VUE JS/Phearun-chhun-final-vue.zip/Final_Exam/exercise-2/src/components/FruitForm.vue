<template>
    <section>
        <form >
            <div class="form-group">
                <label for="">Fruit name</label>
                <input type="text" v-model="fruit">
            </div>
            <div class="form-group">
                <label for="">Fruit color</label>
                <input type="color" v-model="color">
            </div>
            <div class="form-group">
                <button @click="getData">Add fruit</button>
            </div>

        </form>
    </section>
</template>

<script>
export default {
    emits: ['add-fruit'],
    data() {
        return {
            fruit: '',
            color:''
        }
    },
    getData() {
        if (this.fruit !== "") {
            this.$emit('add-fruit',{ fruit: this.fruit, color: this.color })
            this.fruit = "";
            this.color = "";
        }
    },
    removeData(event) {
        this.fruits.splice(event.target.id, 1);
    }
}
</script>

<style scoped>

section {
    border-radius: 10px;
    padding: 10px;
    background: #fff;
    box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
}

.form-group {
    display: flex;
    align-items: center;
    padding: 10px;
    gap: 20px;
}

button {
    border: none;
    cursor: pointer;
    padding: 12px;
    background: #2910a5;
    color: #fff;
    width: 100px;
    border-radius: 40px;
}

input[type="text"] {
    width: 50%;
    border: 1px solid #ccc;
    outline-color: #cce;
    padding: 10px;
}

</style>