<template>
  <div class="container">
    <header>
      <h2>My Fruits</h2>
    </header>

    <fruit-form @add-fruit="getFruit" />
    <fruit-card />

  </div>
</template>

<script>
import FruitForm from './components/FruitForm.vue'
import FruitCard from './components/FruitCard.vue'

export default {
  name: 'App',
  components: {
    'fruit-form': FruitForm,
    'fruit-card':FruitCard
  },
  data() {
    return {
      fruit: "",
      color: "green",
      fruits: []
    }
  },
  
  methods: {
    getFruit(value) {
      this.fruits = value
    }
  },
      provide() { 
        return {
          fruits:this.fruits
        }
      },
}
</script>

<style>
.container {
  width: 40%;
  margin: auto;
  text-align: center;
  font-family: sans-serif;
}

header {
  background: #2910a5;
  color: #fff;
  padding: 20px;
  margin-bottom: 25px;
  border-radius: 10px;
  box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
}
</style>
