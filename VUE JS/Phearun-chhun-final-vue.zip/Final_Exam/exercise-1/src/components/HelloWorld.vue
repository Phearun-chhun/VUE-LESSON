<template>
  <div class="container">
    <header>
      <h2>Final Exam Attendance</h2>
    </header>
    <section>
      <form @submit.prevent="addText">
        <div class="form-group">
          <input type="text" v-model="text">
          <button>Add Student</button>
        </div>
        <p v-if="all_text.length == 0">No student have been added yet - please start adding some!</p>
        <ul v-else v-for="(text,id) in all_text" :key="text" >
          <li @click="removeText($event)" :id="id"> {{text}}.{{id}}</li>
        </ul>
      </form>
    </section>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data() {
    return {
      text: "",
      all_text:[]
    }
  },
  methods: {
    addText() {
      if (this.text != "") {
        this.all_text.push(this.text);
        this.text = "";
      }
    },
    removeText(event) {
      this.all_text.splice(event.target.id, 1)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.container {
  width: 40%;
  margin: auto;
  text-align: center;
  font-family: sans-serif;
}

header {
  background: #69bb69;
  color: #fff;
  padding: 20px;
  margin-bottom: 25px;
  border-radius: 10px;
  box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
}

.form-group {
  display: flex;
  justify-content: center;
}

button {
  border: none;
  cursor: pointer;
  padding: 12px;
  background: #e95353;
  color: #fff;
}

input {
  width: 60%;
  border: 1px solid #ccc;
  outline-color: #cce;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
}

li {
  background: #69bb69;
  padding: 10px;
  margin-top: 10px;
  font-weight: bold;
  border-radius: 40px;
}
</style>
