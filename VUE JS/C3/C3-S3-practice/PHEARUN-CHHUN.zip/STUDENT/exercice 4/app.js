const app = Vue.createApp({
  data() {
    return {
      images: [
        // "https://i.imgur.com/rmydi2w.jpg",
        "https://images6.fanpop.com/image/photos/41100000/-Cute-Little-Kitten-cats-41100525-1920-1280.jpg",
        "https://images6.fanpop.com/image/photos/40200000/Kitten-cats-40265046-1920-1200.jpg",
        "https://images4.fanpop.com/image/photos/14700000/Attack-cats-14749836-1600-1200.jpg",
        "https://images2.fanpop.com/image/photos/9400000/Funny-Cats-cats-9473111-1600-1200.jpg",
        "https://images6.fanpop.com/image/photos/40700000/Cats-cats-40762265-268-268.gif",
        // "https://i.imgur.com/rAFqZiM.jpg",
        // "https://i.imgur.com/Fpw5KKY.jpg",
        // "https://i.imgur.com/IbYRmoW.jpg",
        // "https://i.imgur.com/9poVrgA.jpg",
      ],
      currentImage: 0,
    };
  },
  methods: {
    previousImage: function (e) {
      if (this.currentImage !== 0) {
        this.currentImage--;
      }
    },
    nextImage: function (e) {
      if (this.currentImage !==(this.images.length - 1)) {
        this.currentImage++;
      }
    }
  },
});

app.mount("#app");
