const app = Vue.createApp({
  data() {
    return {
      value:"",
    };
  },
  methods: {
    alert() {
      alert("alert")
    }
  },
});

app.mount("#app");
