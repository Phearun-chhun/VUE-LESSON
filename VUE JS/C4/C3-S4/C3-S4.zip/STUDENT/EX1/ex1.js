const app =  Vue.createApp({
  data() {
    return{
      result: 0,
    }
  },
  methods: {
    computeOperation() {
    
    },
  },
});


app.mount("#exercise");