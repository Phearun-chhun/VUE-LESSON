const app = Vue.createApp({
  data() {
    return{
      htmlAverage:0,
      scores: [
        { name: "a", topic: "HTML", result: 30 },
        { name: "b", topic: "JAVA", result: 40 },
        { name: "c", topic: "JS", result: 51 },
      ],
    }
  },
   
});

app.mount("#exercise")
