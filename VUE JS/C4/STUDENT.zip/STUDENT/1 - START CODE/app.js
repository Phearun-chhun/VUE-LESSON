const app = Vue.createApp({
  data() {
    return {};
  },

  methods: {},

  computed: {},
});

app.mount("#app");
