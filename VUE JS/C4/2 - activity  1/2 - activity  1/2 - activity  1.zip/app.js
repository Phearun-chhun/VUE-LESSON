const app = Vue.createApp({
  data() {
    return {
      boxASelected: false,
    };
  },
  methods: {
    boxSelected() {
      this.boxASelected = !this.boxASelected;
    },
  },
});

app.mount("#styling");
