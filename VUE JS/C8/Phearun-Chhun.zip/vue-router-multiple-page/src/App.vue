<template>
  <section>
    <navigation></navigation>
    <router-view></router-view>
  </section>
</template>

<script>
import Navigation from "./components/nav/NavigationView.vue";
export default {
  components: { Navigation },
  data() {
    return {
      students: [
        { id: 1, name: "Manuel Lorenz", age: 21 },
        { id: 2, name: "Julie Jone", age: 31 },
        { id: 3, name: "Phearun Chhun", age: 20 },
        { id: 4, name: "Pharob Sok", age: 21 },
      ],
      teachers: [
        { id: 1, name: "Rysan", position: "WEB Trainer" },
        { id: 2, name: "Setha", position: "English Trainer" },
        { id: 3, name: "Phearath", position: "WEP Coordinator" },
        { id: 4, name: "Reaksa", position: "Professional Life Trainer" },
      ],
    };
  },
  provide() {
    return {
      students: this.students,
      teachers: this.teachers,
    };
  },
};
</script>

<style scoped>
body{
  margin: 0;
  padding: 0;
}

</style>
