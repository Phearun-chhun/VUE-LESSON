<template>
  <ul>
    <li>
      <teacher-card v-for="teacher in teachers" :key="teacher.id" :teacherId="teacher.id" :teacherName="teacher.name"
        :teacherPosition="teacher.position">
      </teacher-card>
    </li>
  </ul>
</template>
<script>
import TeacherCard from "./TeacherCard.vue";
export default {
  components: { TeacherCard },
  inject: ["teachers"],
};
</script>

<style scoped>
ul {
  list-style: none;
  margin-top: 5%;
}

li {
  width: 40rem;
  margin: 2rem auto;
  padding: 1rem;
  border: 1px solid #ccc;
}

li section {
  padding: 10px;
  margin: 10px;
  box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
}
</style>
