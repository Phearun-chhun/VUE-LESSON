<template>
    <section>
        <h2>Name : {{ teacherInfo }}</h2>
    </section>
</template>

<script>
export default {
    props: [
        "teacherId"
    ],
    inject: [
        "teachers"
    ],
    computed: {
        teacherInfo() {
            for (let teacher of this.teachers) {
                if (teacher.id == this.teacherId) {
                    return teacher.name;
                }
            }
            return 'no name';   
        }
    }
};
</script>

<style scoped>
section {
    width: 60%;
    margin: auto;
    margin-top: 5%;
    box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
}

h2 {
    padding: 10px;
    text-align: center;
}
</style>
