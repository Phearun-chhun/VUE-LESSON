<template>
    <section>
        <h2>Name : {{ teacherName }}</h2>
        <h2>Position : {{ teacherPosition }}</h2>
    </section>
</template>
<script>
export default {
    props: ["teacherName", "teacherPosition", "teacherId"],
    
};
</script>

<style>
</style>
