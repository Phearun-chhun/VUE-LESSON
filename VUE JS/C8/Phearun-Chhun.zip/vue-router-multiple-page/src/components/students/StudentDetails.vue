<template>
  <section>
    <h2>Name : {{ studentInfo }}</h2>
  </section>
</template>

<script>
export default {
  props: [
    "studentId"
  ],
  inject: [
    "students"
  ],
  computed: {
    studentInfo() {
      for (let student of this.students) {
        if (student.id == this.studentId) {
          return student.name;
        }
      }
      return 'no name';
    }
  }
};
</script>

<style scoped>

  section {
    width: 60%;
    margin:auto;
    margin-top: 5%;
    box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
  }
  h2 {
    padding: 10px;
    text-align: center;
    }
</style>
