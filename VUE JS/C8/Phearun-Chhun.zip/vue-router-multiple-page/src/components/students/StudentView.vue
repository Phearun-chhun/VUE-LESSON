<template>
  <ul>
    <li>
      <student-card
        v-for="student in students"
        :key="student.id"
        :studentId="student.id"
        :studentName="student.name"
        :studentAge="student.age"
      >
      </student-card>
    </li>
  </ul>
</template>
<script>
import StudentCard from "./StudentCard.vue";
export default {
  components: { StudentCard },
  inject: ["students"],
};
</script>

<style scoped>


ul {
  list-style: none;
  margin-top: 5%;
}
li {
  width: 40rem;
  margin: 2rem auto;
  padding: 1rem;
  border: 1px solid #ccc;
}
li section {
  padding: 10px;
  margin: 10px;
box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
  }
</style>
