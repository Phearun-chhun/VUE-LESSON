<template>
  <section>
    <h2>Name : {{ studentName }}</h2>
    <h2>Age : {{ studentAge }}</h2>
    <button @click="onClick">Show Details</button>
  </section>
</template>
<script>
export default {
  props: ["studentName", "studentAge","studentId"],
  methods: {
    onClick() {
      this.$router.push("/students/"+this.studentId)
    }
  }
};
</script>

<style></style>
