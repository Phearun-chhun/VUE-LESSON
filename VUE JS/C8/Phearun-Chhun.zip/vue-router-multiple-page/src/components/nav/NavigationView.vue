<template>
  <header>
    <nav>
      <ul>
       <router-link to="/teachers"> <li>Teacher</li></router-link>
        <router-link to="/students"><li>Students</li></router-link> 
      </ul>
    </nav>
  </header>
</template>


<style scoped>
*{
  padding: 0;
  margin: 0;
}
header {
  width: 100%;
  color:#fff;
  background-color: #08b8cc;
  position: fixed;
  left: 0;
  right: 0;
  top: 0;
  z-index: 9999;
}

nav {
  width: 100%;

}

ul {
  list-style: none;
  margin: 0;
  padding: 10px;
  height: 100%;
  display: flex;

}

li {
  padding: 5px;
  font-size: 1.5rem;
}

/* a {
  text-decoration: none;
  background: transparent;
  border: 1px solid transparent;
  cursor: pointer;
  color: white;
  padding: 0.5rem 1.5rem;
  display: inline-block;
}

a:hover,
a:active {
  color: #f1a80a;
  border-color: #f1a80a;
  background-color: #1a037e;
} */
</style>
