import { createApp } from "vue";
import { createRouter, createWebHistory } from "vue-router";

import App from "./App.vue";
import StudentView from "@/components/students/StudentView.vue";
import TeacherView from "@/components/teachers/TeachersView.vue";
import TeacherDetail from "@/components/teachers/TeacherDetail.vue";
import StudentInformation from "@/components/students/StudentDetails.vue";
const app = createApp(App);

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: "/students", component: StudentView },
    { path: "/teachers", component: TeacherView },
    {
      path: "/teachers/:teacherId",
      component: TeacherDetail,
      props: true,
    },
    {
      path: "/students/:studentId",
      component: StudentInformation,
      props: true,
    },
  ],
});

app.use(router);

app.mount("#app");
